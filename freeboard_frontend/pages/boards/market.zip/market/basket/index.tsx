import MarketBasketContainer from "../../../../src/components/units/board/market/baskets/MarketBasket.container";

export default function MarketBasketPage() {
  return <MarketBasketContainer />;
}
