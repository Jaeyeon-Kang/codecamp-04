import MarketDetailContainer from "../../../../src/components/units/board/market/detail/MarketDetail.container";

export default function MarketDetailPage() {
  return <MarketDetailContainer />;
}
