import MarketListContainer from "../../../../src/components/units/board/market/list/MarketList.container";

export default function MarketListPage() {
  return <MarketListContainer />;
}
